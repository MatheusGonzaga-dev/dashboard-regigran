<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class GrupoTempSeeder extends Seeder
{
    public function run()
    {
        
        $grupoModel = new \App\Models\GrupoModel();

        $grupos = [
            [
                'nome' => 'Administrador',
                'descricao' => 'Grupo com acesso total ao sistema',
                'exibir' => false,
            ],
            [
                'nome' => 'Clientes',
                'descricao' => 'Grupo destinado para atribuição de clientes',
                'exibir' => false,
            ],
            [
                'nome' => 'Administrativo',
                'descricao' => 'Grupo com acesso a questões administrativa',
                'exibir' => false,
            ],
        ];

        foreach ($grupos as $grupo) {
            $grupoModel->insert($grupo);
        }

            echo "Grupos criados com sucesso!";

    }
}
