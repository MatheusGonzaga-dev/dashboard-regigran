<?php

namespace App\Controllers;

use App\Controllers\BaseController;



class Login extends BaseController
{
    public function novo()
    {
        
        $data = [
            'titulo' => 'Realize o login',
        ];

        return view('Login/novo', $data);


    }


    public function criar(){

        if (!$this->request->isAJAX()) {
            return redirect()->back();
        }

        $retorno['token'] = csrf_hash();

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');   
        
        $autenticacao = service('autenticacao');

        if($autenticacao->login($email, $password) === false){

            //credenciais invalidas
            $retorno['erro'] = 'Por favor verifique os erro abaixo e tente novamente';
            $retorno['erros_model'] = ['credenciais' => 'Não encontramos suas credenciais de acesso!'];
            return $this->response->setJSON($retorno);
        }

        //credenciais validas
        exit("validado");

    }
}
