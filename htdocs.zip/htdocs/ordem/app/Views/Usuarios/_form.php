<div class="form-group">
    <label for="nome">Nome Completo</label>
    <input type="text" id="nome" name="nome" placeholder="Insira o nome completo" class="form-control" value="<?php echo esc($usuario->nome); ?>">
</div>

<div class="form-group">
    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" placeholder="Insira o E-mail Completo de acesso" class="form-control" value="<?php echo esc($usuario->email); ?>">
</div>

<div class="form-group">
    <label for="password">Senha</label>
    <input type="password" id="password" name="password" placeholder="Senha de acesso" class="form-control">
</div>

<div class="form-group">
    <label for="password_confirmation">Confirmação de Senha</label>
    <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Confirme a Senha de acesso" class="form-control">
</div>

<div class="form-check">
    <input type="hidden" name="ativo" value="0">
    <input type="checkbox" id="ativo" name="ativo" value="1" class="form-check-input" <?php if($usuario->ativo == true): ?> checked <?php endif;?>>
    <label class="form-check-label" for="ativo">Usuário ativo</label>
</div>
