<?= $this->extend('Layout/principal') ?>

<?= $this->section('titulo') ?>
<?php echo $titulo; ?>
<?= $this->endSection() ?>

<?= $this->section('estilos') ?>

<?= $this->endSection() ?>


<?= $this->section('conteudo') ?>

<div class="row">

  <div class="col-lg-6">

    <div class="block-body">


      <?php echo form_open("grupos/excluir/$grupo->id") ?>

      
        <div class="alert alert-warning" role="alert">
            Tem certeza que deseja excluir do registro?
        </div>
      
        <div class="form-group mt-5 mb-2">

          <input id="btn-salvar" type="submit" value="Sim, pode excluir" class="btn btn-sm btn-danger mr-2">

          <a href="<?php echo site_url("grupos/exibir/$grupo->id") ?>" class="btn btn-sm btn-secondary btn-sm ml-2">Cancelar</a>

        </div>

        <?php echo form_close(); ?>

      



    </div>


  </div>




  <?= $this->endSection() ?>

  <?= $this->section('scripts') ?>





  <?= $this->endSection() ?>