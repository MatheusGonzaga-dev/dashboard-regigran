<div class="form-group">
    <label for="nome">Nome</label>
    <input type="text" id="nome" name="nome" placeholder="Insira o nome do grupo de acesso" class="form-control" value="<?php echo esc($grupo->nome); ?>">
</div>

<div class="form-group">
    <label for="nome">Descricao</label>
    <textarea name="descricao" placeholder="Insira a descrição do grupo de acesso" class="form-control"><?php echo esc($grupo->descricao); ?></textarea>
</div>



<div class="form-check">
    <input type="hidden" name="exibir" value="0">
    <input type="checkbox" id="exibir" name="exibir" value="1" class="form-check-input" <?php if($grupo->exibir == true): ?> checked <?php endif;?>>
    <label class="form-check-label" for="exibir">Exibir grupo de acesso</label>

    <a tabindex="0" class="" role="button" data-toggle="popover" data-trigger="focus"
    title="Importante!!" data-content="Se este grupo for definido como <b>Exibir grupo de acesso</b> o usuário terá o acesso para <b>Responsavel</b> Técnico">
    &nbsp;&nbsp;<i class="fa fa-question-circle fa-lg text-danger"></i></a>
</div>
