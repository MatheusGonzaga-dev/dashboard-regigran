<?= $this->extend('Layout/principal') ?>

<?= $this->section('titulo') ?>
<?php echo $titulo; ?>
<?= $this->endSection() ?>

<?= $this->section('estilos') ?>

<?= $this->endSection() ?>


<?= $this->section('conteudo') ?>

<div class="row">

  <div class="col-lg-4">


    <?php if($grupo->id < 2): ?>

      <div class="alert alert-info" role="alert">
      <h4 class="alert-heading">Importante!</h4>
      <p>O grupo <b><?php echo esc($grupo->nome); ?></b> Não pode ser editado ou excluído</p>
      <hr>
      <p class="mb-0">Os demais grupos podem ser editados ou removidos!</p>

    </div>

    <?php endif; ?>


    <div class="user-block block">

      <h5 class="card-title mt-2"><?php echo esc($grupo->nome); ?></h5>
      <p class="contributions mt-0"><?php echo $grupo->exibeSituacao()?></p>

      <?php if($grupo->deletado_em == null): ?>
      <a tabindex="0" class="" role="button" data-toggle="popover" data-trigger="focus" title="Importante!!" data-content="Este grupo <?php echo ($grupo->exibir == true ? 'será' : 'não será')?> exibido como opção na hora de definir um <b>Responsavel</b> Técnico">&nbsp;&nbsp<i class="fa fa-question-circle fa-lg text-danger"></i></a>
      <?php endif; ?>

      <p class="card-text"><?php echo esc($grupo->descricao);?></p>
      <p class="card-text">Criado <?php echo $grupo->criado_em->humanize(); ?></p>
      <p class="card-text">Atualizado <?php echo $grupo->atualizado_em->humanize(); ?></p>

      <?php if($grupo->id > 2): ?>
      <div class="d-flex">
        <div class="btn-group mr-2">

          <button type="button" class="btn btn-danger btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Ações
          </button>

          <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo site_url("grupos/editar/$grupo->id");?>">Editar Grupo de Acesso</a>
            
            
            <?php if($grupo->id > 2): ?>

              <a class="dropdown-item" href="<?php echo site_url("grupos/permissoes/$grupo->id");?>">Permissões Grupo de acesso</a>

            <?php endif; ?>
            
            <div class="dropdown-divider"></div>

            <?php if($grupo->deletado_em == null): ?>
            <a class="dropdown-item" href="<?php echo site_url("grupos/excluir/$grupo->id"); ?>">Excluir Grupo de Acesso</a>
            <?php else: ?>
            <a class="dropdown-item" href="<?php echo site_url("grupos/desfazerexclusao/$grupo->id"); ?>">Restaurar grupo de acesso</a>
            <?php endif; ?>
          </div>

        </div>

        <a href="<?php echo site_url("grupos")?>" class="btn btn-secondary btn-sm ml-2">Voltar</a>
      </div>
      <?php else: ?>
      <a href="<?php echo site_url("grupos")?>" class="btn btn-secondary btn-sm ">Voltar</a>
      <?php endif; ?>

    </div> <!-- /.user-block -->

  </div> <!-- /.col-lg-4 -->

</div> <!-- /.row -->

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>

<?= $this->endSection() ?>
